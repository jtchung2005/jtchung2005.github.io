$(document).ready(function(){
$(".burgermenu").click(function(){
    $(".mob-nav").slideToggle();
  });}
)

  $(".mob-nav").css("margin-left", "-70px");